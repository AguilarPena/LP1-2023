# LG_23
Programa simulando Pregão da bolsa
